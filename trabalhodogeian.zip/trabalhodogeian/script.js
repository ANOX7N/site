// ==========================================
// DADOS ORIGINAIS (Usados apenas na 1ª vez)
// ==========================================
const dbOriginal = {
    "3º Ano - Informática": [
        { nome: "Alan Oliveira Sousa", foto: "" },
        { nome: "Beatriz Cavalcante Braga", foto: "" },
        { nome: "Camila Rocha Silva", foto: "" }
    ],
    "1º Ano - Administração": [
        { nome: "Diego Lima Nogueira", foto: "" },
        { nome: "Lucas Mateus Santos", foto: "" }
    ]
};

// Variáveis Globais que o app vai usar
let bdTurmas = {};
let pautaFrequencia = {};
let sessaoAtiva = { email: "", isProf: false, turmaDiario: "", turmaEdicao: "" };
let bdHistorico = [];
let aulaAtiva = 0; // Nova variável: Controla qual das 9 aulas está selecionada (0 = 1ª Aula, 8 = 9ª Aula)

document.addEventListener('DOMContentLoaded', () => {
    const inputData = document.getElementById('data-hoje');
    if (inputData) inputData.value = new Date().toISOString().split('T')[0];
});

// ==========================================
// 1. SISTEMA DE SALVAMENTO AUTOMÁTICO
// ==========================================
function carregarDadosLocais() {
    const turmasSalvas = localStorage.getItem('sge_bd_turmas');
    const frequenciaSalva = localStorage.getItem('sge_bd_frequencia');
    const historicoSalvo = localStorage.getItem('sge_bd_historico');

    if (turmasSalvas) bdTurmas = JSON.parse(turmasSalvas);
    else bdTurmas = JSON.parse(JSON.stringify(dbOriginal));

    if (frequenciaSalva) pautaFrequencia = JSON.parse(frequenciaSalva);
    else pautaFrequencia = {};

    if (historicoSalvo) bdHistorico = JSON.parse(historicoSalvo);
    else bdHistorico = [];
}

// ==========================================
// 2. SESSÃO E LOGIN
// ==========================================
function executarAutenticacao(event) {
    event.preventDefault(); // Impede o HTML de recarregar a página sozinho

    const emailDigitado = document.getElementById('email').value;
    const senhaDigitada = document.getElementById('senha').value;

    // Envia os dados de forma assíncrona para o arquivo PHP validar no servidor
    fetch('auth.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            email: emailDigitado,
            senha: senhaDigitada
        })
    })
        .then(resposta => resposta.json()) // Converte a resposta do PHP para Objeto JS
        .then(dados => {
            if (dados.sucesso) {
                // Se o PHP deu ok, salva a sessão exatamente como a sua função 'verificarSessao' necessita
                localStorage.setItem('sge_sessao', JSON.stringify({
                    email: dados.email,
                    isProf: dados.isProf
                }));

                // Redireciona para o app.html (que continua sendo HTML puro!)
                window.location.href = 'app.html';
            } else {
                // Se o PHP recusar, dispara o seu Toast vermelho com a mensagem que veio do PHP
                dispararToast('danger', dados.mensagem);
            }
        })
        .catch(erro => {
            console.error("Erro na requisição:", erro);
            dispararToast('danger', 'Erro crítico: Não foi possível conectar ao servidor PHP.');
        });
}

function verificarSessao() {
    const dadosSessao = JSON.parse(localStorage.getItem('sge_sessao'));
    // Garanta que está 'login.html' aqui:
    if (!dadosSessao) { window.location.href = 'login.html'; return; }

    carregarDadosLocais();
    sessaoAtiva.email = dadosSessao.email;
    sessaoAtiva.isProf = dadosSessao.isProf;

    let extrairNome = sessaoAtiva.email.split('@')[0].split('.')[0];
    let nomeFormatado = extrairNome.charAt(0).toUpperCase() + extrairNome.slice(1);
    document.getElementById('nome-usuario-logado').innerText = nomeFormatado;
    document.getElementById('txt-avatar').innerText = nomeFormatado.charAt(0);

    const turmasExistentes = Object.keys(bdTurmas);
    if (turmasExistentes.length > 0) {
        sessaoAtiva.turmaDiario = turmasExistentes[0];
        sessaoAtiva.turmaEdicao = turmasExistentes[0];
    }

    if (!sessaoAtiva.isProf) {
        document.body.classList.remove('is-prof');

        let turmaDoLider = "";
        let nomeRealDoLider = "";
        let cargoDoAluno = "Líder de Turma"; // Padrão de segurança

        // O SISTEMA VAI CAÇAR O ALUNO EM TODAS AS TURMAS PELO EMAIL DE LOGIN
        for (let nomeTurma in bdTurmas) {
            let alunoEncontrado = bdTurmas[nomeTurma].find(a => a.email === sessaoAtiva.email);
            if (alunoEncontrado) {
                turmaDoLider = nomeTurma;
                nomeRealDoLider = alunoEncontrado.nome;

                // Identifica dinamicamente o cargo salvo para exibir na barra lateral
                if (alunoEncontrado.cargo === 'vice') cargoDoAluno = "Vice-Líder";
                else if (alunoEncontrado.cargo === 'secretario') cargoDoAluno = "Secretário(a)";
                else cargoDoAluno = "Líder de Turma";

                break; // Achou a turma e o cargo, para a busca
            }
        }

        // Se o aluno logou mas nenhum professor deu cargo para ele:
        if (!turmaDoLider) {
            alert("Acesso Negado!\nSeu e-mail não foi cadastrado na liderança de nenhuma turma. Procure o seu professor.");
            encerrarSessao();
            return;
        }

        // Define o texto do cargo correto na barra lateral
        document.getElementById('cargo-usuario').innerText = cargoDoAluno;

        // Se ele for da liderança, trava o aplicativo apenas na turma dele
        sessaoAtiva.turmaDiario = turmaDoLider;
        document.getElementById('wrapper-seletor-turma').innerHTML = `<input type="text" class="input-form input-readonly" readonly value="${sessaoAtiva.turmaDiario}">`;

        // Coloca o nome real do aluno na barra lateral em vez do e-mail
        document.getElementById('nome-usuario-logado').innerText = nomeRealDoLider;
        document.getElementById('txt-avatar').innerText = nomeRealDoLider.charAt(0);

    } else {
        document.body.classList.add('is-prof');
        document.getElementById('cargo-usuario').innerText = "Professor / Gestor";
        atualizarSeletoresTurma();
    }

    inicializarPautaPadrao();
    sincronizarInterface();

    // Renderiza o dashboard escondido para deixar pronto
    if (sessaoAtiva.isProf) setTimeout(renderizarDashboard, 500);
}

function encerrarSessao() {
    localStorage.removeItem('sge_sessao');
    window.location.href = 'login.html';
}

function salvarDadosLocais() {
    localStorage.setItem('sge_bd_turmas', JSON.stringify(bdTurmas));
    localStorage.setItem('sge_bd_frequencia', JSON.stringify(pautaFrequencia));
    localStorage.setItem('sge_bd_historico', JSON.stringify(bdHistorico));
}

// Unificado e corrigido para alternar abas e atualizar títulos dinamicamente
function alternarAbas(idAba, elementoBotao) {
    document.querySelectorAll('.painel-modulo').forEach(el => el.classList.remove('ativo'));
    document.querySelectorAll('.nav-btn').forEach(el => el.classList.remove('ativo'));

    const painel = document.getElementById(idAba);
    if (painel) painel.classList.add('ativo');
    if (elementoBotao) elementoBotao.classList.add('ativo');

    // Muda os Títulos Dinamicamente
    const titulos = {
        'aba-diario': ['Módulo de Diário Eletrônico', 'Lançamento de Frequência'],
        'aba-gerenciar-turma': ['Gestão de Turmas', 'Adição e Edição de Alunos'],
        'aba-secretaria': ['Painel Consolidador SIGE', 'Relatórios, Gráficos e Riscos']
    };

    if (titulos[idAba]) {
        document.getElementById('txt-titulo-modulo').innerText = titulos[idAba][0];
        document.getElementById('txt-subtitulo-modulo').innerText = titulos[idAba][1];
    }

    if (idAba === 'aba-secretaria') {
        atualizarFiltroTurmaSecretaria();
        renderizarHistoricoSecretaria();
        if (typeof renderizarDashboard === 'function') renderizarDashboard();
    }
}

// ==========================================
// 3. RENDERS E COMPONENTES GLOBAIS
// ==========================================
function atualizarSeletoresTurma() {
    if (!sessaoAtiva.isProf) return;
    const turmas = Object.keys(bdTurmas);
    let opcoesHtml = turmas.map(t => `<option value="${t}">${t}</option>`).join('');

    if (turmas.length === 0) opcoesHtml = `<option value="">Nenhuma turma cadastrada</option>`;

    document.getElementById('wrapper-seletor-turma').innerHTML = `<select class="input-form" id="sel-diario" onchange="mudarTurmaDiario(this.value)">${opcoesHtml}</select>`;
    if (document.getElementById('sel-diario')) document.getElementById('sel-diario').value = sessaoAtiva.turmaDiario;

    document.getElementById('wrapper-seletor-edicao-turma').innerHTML = `<select class="input-form" id="sel-edicao" onchange="mudarTurmaEdicao(this.value)">${opcoesHtml}</select>`;
    if (document.getElementById('sel-edicao')) document.getElementById('sel-edicao').value = sessaoAtiva.turmaEdicao;

    // NOVO SELETOR PARA O DASHBOARD DA SECRETARIA
    const seletorRelatorio = document.getElementById('wrapper-seletor-relatorio');
    if (seletorRelatorio) {
        seletorRelatorio.innerHTML = `<select class="input-form" id="sel-relatorio" onchange="renderizarDashboard()">${opcoesHtml}</select>`;
    }
    const modalAlunoTurma = document.getElementById('modal-aluno-turma');
    if (modalAlunoTurma) modalAlunoTurma.innerHTML = opcoesHtml;
}

// ==========================================
// 4. GESTÃO DE TURMAS (CRUD)
// ==========================================
function criarTurma() {
    let nome = prompt("Digite o nome e o ano da nova turma (Ex: 1º Ano - Finanças):");
    if (!nome) return;
    if (bdTurmas[nome]) {
        dispararToast('warning', 'Já existe uma turma com este nome.');
        return;
    }
    bdTurmas[nome] = [];
    sessaoAtiva.turmaEdicao = nome;

    salvarDadosLocais();
    atualizarSeletoresTurma();
    sincronizarInterface();
    dispararToast('success', 'Nova turma criada!');
}

function renomearTurma() {
    const nomeAtual = sessaoAtiva.turmaEdicao;
    if (!nomeAtual) return dispararToast('warning', 'Nenhuma turma selecionada.');

    let novoNome = prompt("Renomear turma:", nomeAtual);
    if (!novoNome || novoNome === nomeAtual) return;

    if (bdTurmas[novoNome]) return dispararToast('warning', 'Nome já em uso.');

    bdTurmas[novoNome] = bdTurmas[nomeAtual];
    delete bdTurmas[nomeAtual];

    sessaoAtiva.turmaEdicao = novoNome;
    if (sessaoAtiva.turmaDiario === nomeAtual) sessaoAtiva.turmaDiario = novoNome;

    salvarDadosLocais();
    atualizarSeletoresTurma();
    sincronizarInterface();
    dispararToast('success', 'Turma renomeada com sucesso.');
}

function excluirTurma() {
    const nomeAtual = sessaoAtiva.turmaEdicao;
    if (!nomeAtual) return;

    if (confirm(`Tem certeza que deseja APAGAR a turma "${nomeAtual}" e TODOS os seus alunos?`)) {
        bdTurmas[nomeAtual].forEach(aluno => delete pautaFrequencia[aluno.nome]);
        delete bdTurmas[nomeAtual];

        const turmasRestantes = Object.keys(bdTurmas);
        sessaoAtiva.turmaEdicao = turmasRestantes.length > 0 ? turmasRestantes[0] : "";
        sessaoAtiva.turmaDiario = sessaoAtiva.turmaEdicao;

        salvarDadosLocais();
        atualizarSeletoresTurma();
        inicializarPautaPadrao();
        sincronizarInterface();
        dispararToast('danger', 'Turma deletada do sistema.');
    }
}

function mudarTurmaDiario(novaTurma) { sessaoAtiva.turmaDiario = novaTurma; inicializarPautaPadrao(); sincronizarInterface(); }
function mudarTurmaEdicao(novaTurma) { sessaoAtiva.turmaEdicao = novaTurma; renderizarListagemCrud(); }

// ==========================================
// 5. DIÁRIO E FREQUÊNCIA
// ==========================================
function getAvatarDefault(nome) {
    return `https://ui-avatars.com/api/?name=${encodeURIComponent(nome)}&background=0284C7&color=fff&bold=true`;
}

// CORREÇÃO: Força sempre voltar para "P" por padrão quando o usuário loga
function inicializarPautaPadrao() {
    if (!sessaoAtiva.turmaDiario || !bdTurmas[sessaoAtiva.turmaDiario]) return;
    bdTurmas[sessaoAtiva.turmaDiario].forEach(aluno => {
        pautaFrequencia[aluno.nome] = Array(9).fill('P');
    });
    salvarDadosLocais();
}

function alternarStatusAula(nomeEstudante, indiceAula) {
    if (!Array.isArray(pautaFrequencia[nomeEstudante])) {
        pautaFrequencia[nomeEstudante] = Array(9).fill('P');
    }

    let statusAtual = pautaFrequencia[nomeEstudante][indiceAula];
    let novoStatus = 'P';

    if (statusAtual === 'P') novoStatus = 'F';
    else if (statusAtual === 'F') novoStatus = 'J';
    else if (statusAtual === 'J') novoStatus = 'P';

    pautaFrequencia[nomeEstudante][indiceAula] = novoStatus;
    salvarDadosLocais();
    sincronizarInterface();
}

function marcarFrequenciaAula(nomeEstudante, status) {
    if (!Array.isArray(pautaFrequencia[nomeEstudante])) {
        pautaFrequencia[nomeEstudante] = Array(9).fill('P');
    }
    pautaFrequencia[nomeEstudante][aulaAtiva] = status;
    salvarDadosLocais();
    sincronizarInterface();
}

function calcularMetricas() {
    if (!bdTurmas[sessaoAtiva.turmaDiario]) {
        document.getElementById('card-total-alunos').innerText = "0";
        document.getElementById('card-faltosos').innerText = "0";
        document.getElementById('card-frequencia').innerText = "0%";
        return;
    }

    const alunos = bdTurmas[sessaoAtiva.turmaDiario];
    let totalAlunos = alunos.length;
    let totalAulasPossiveis = totalAlunos * 9;
    let faltasTotais = 0;
    let alunosComFalta = 0;

    alunos.forEach(aluno => {
        let arr = pautaFrequencia[aluno.nome];
        if (!Array.isArray(arr)) arr = Array(9).fill('P');

        let faltasDoAluno = arr.filter(st => st === 'F').length;
        faltasTotais += faltasDoAluno;
        if (faltasDoAluno > 0) alunosComFalta++;
    });

    let frequenciaMedia = totalAulasPossiveis === 0 ? 0 : ((totalAulasPossiveis - faltasTotais) / totalAulasPossiveis) * 100;

    document.getElementById('card-total-alunos').innerText = totalAlunos;
    document.getElementById('card-faltosos').innerText = alunosComFalta;
    document.getElementById('card-frequencia').innerText = frequenciaMedia.toFixed(1) + '%';
}

function renderizarGridChamada() {
    const alvo = document.getElementById('area-lista-alunos');
    if (!bdTurmas[sessaoAtiva.turmaDiario] || bdTurmas[sessaoAtiva.turmaDiario].length === 0) {
        alvo.innerHTML = `<p style="padding:40px; text-align:center; color:var(--texto-s);">Nenhum estudante nesta turma.</p>`;
        return;
    }

    let html = `<table class="tabela-sge"><thead><tr><th width="10%">Nº</th><th width="50%">Estudante</th><th width="40%" style="text-align: right;">Preenchimento Rápido</th></tr></thead><tbody>`;

    const alunosSort = [...bdTurmas[sessaoAtiva.turmaDiario]].sort((a, b) => a.nome.localeCompare(b.nome));

    alunosSort.forEach((aluno, idx) => {
        if (!pautaFrequencia[aluno.nome] || !Array.isArray(pautaFrequencia[aluno.nome])) {
            pautaFrequencia[aluno.nome] = Array(9).fill('P');
        }

        let arrStatus = pautaFrequencia[aluno.nome];
        let fotoUrl = aluno.foto || getAvatarDefault(aluno.nome);

        let todasIguais = arrStatus.every(val => val === arrStatus[0]);
        let stGeral = todasIguais ? arrStatus[0] : '';

        let trackerAulas = `<div style="display: flex; gap: 6px; margin-top: 6px; align-items: center;">`;
        for (let i = 0; i < 9; i++) {
            let stAula = arrStatus[i] || 'P';
            let corBg = '#16a34a';
            if (stAula === 'F') corBg = '#dc2626';
            if (stAula === 'J') corBg = '#f59e0b';

            trackerAulas += `
                <span onclick="alternarStatusAula('${aluno.nome}', ${i})" 
                      title="Aula ${i + 1} - Clique para alterar" 
                      style="display: inline-block; width: 16px; height: 16px; border-radius: 4px; background: ${corBg}; color: white; font-size: 9px; text-align: center; line-height: 16px; font-family: sans-serif; cursor: pointer; transition: transform 0.1s; user-select: none;"
                      onmouseover="this.style.transform='scale(1.15)'" 
                      onmouseout="this.style.transform='scale(1)'">
                    ${stAula}
                </span>`;
        }
        trackerAulas += `</div>`;

        html += `
            <tr>
                <td><strong>${String(idx + 1).padStart(2, '0')}</strong></td>
                <td>
                    <div class="aluno-info-linha" style="align-items: flex-start; flex-direction: column; gap: 2px;">
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <img src="${fotoUrl}" class="avatar-aluno" alt="Foto">
                            <span style="font-weight: 500;">${aluno.nome}</span>
                        </div>
                        ${trackerAulas}
                    </div>
                </td>
                <td style="text-align: right; vertical-align: middle;">
                    <div class="status-group" style="justify-content: flex-end;">
                        <button title="Aplicar P a todas as aulas" class="st-btn p ${stGeral === 'P' ? 'ativo' : ''}" onclick="marcarDiaTodo('${aluno.nome}', 'P')">P</button>
                        <button title="Aplicar F a todas as aulas" class="st-btn f ${stGeral === 'F' ? 'ativo' : ''}" onclick="marcarDiaTodo('${aluno.nome}', 'F')">F</button>
                        <button title="Aplicar J a todas as aulas" class="st-btn j ${stGeral === 'J' ? 'ativo' : ''}" onclick="marcarDiaTodo('${aluno.nome}', 'J')">J</button>
                    </div>
                </td>
            </tr>
        `;
    });

    html += `</tbody></table>`;
    alvo.innerHTML = html;
}

function sincronizarInterface() {
    calcularMetricas();
    renderizarGridChamada();
    if (sessaoAtiva.isProf) renderizarListagemCrud();
}

// ==========================================
// 6. GESTÃO DE ALUNOS (CRUD E MOVER)
// ==========================================
function renderizarListagemCrud() {
    const alvo = document.getElementById('area-gerenciamento-alunos');
    if (!alvo) return;
    alvo.innerHTML = "";

    if (!bdTurmas[sessaoAtiva.turmaEdicao] || bdTurmas[sessaoAtiva.turmaEdicao].length === 0) {
        alvo.innerHTML = `<p style="padding:24px; text-align:center; color:var(--texto-s);">A turma está vazia.</p>`;
        return;
    }

    const alunosSort = [...bdTurmas[sessaoAtiva.turmaEdicao]].sort((a, b) => a.nome.localeCompare(b.nome));

    let qtdLider = alunosSort.filter(a => a.cargo === 'lider').length;
    let qtdVice = alunosSort.filter(a => a.cargo === 'vice').length;
    let qtdSec = alunosSort.filter(a => a.cargo === 'secretario').length;

    alunosSort.forEach((aluno) => {
        let fotoUrl = aluno.foto || getAvatarDefault(aluno.nome);

        let badge = '';
        if (aluno.cargo === 'lider') badge = `<span class="badge-lider" title="${aluno.email}">Líder</span>`;
        else if (aluno.cargo === 'vice') badge = `<span class="badge-lider" title="${aluno.email}" style="background:#f59e0b;">Vice</span>`;
        else if (aluno.cargo === 'secretario') badge = `<span class="badge-lider" title="${aluno.email}" style="background:#10b981;">Sec.</span>`;

        let botaoCargo = '';
        if (aluno.cargo) {
            botaoCargo = `<button class="btn-linha-crud" onclick="removerCargo('${aluno.nome}')">Remover Cargo</button>`;
        } else {
            if (qtdLider === 0) {
                botaoCargo = `<button class="btn-linha-crud btn-lider" onclick="atribuirCargo('${aluno.nome}', 'lider')">Eleger Líder</button>`;
            } else if (qtdVice === 0) {
                botaoCargo = `<button class="btn-linha-crud btn-lider" onclick="atribuirCargo('${aluno.nome}', 'vice')">Eleger Vice</button>`;
            } else if (qtdSec < 2) {
                botaoCargo = `<button class="btn-linha-crud btn-lider" onclick="atribuirCargo('${aluno.nome}', 'secretario')">Eleger Sec.</button>`;
            }
        }

        alvo.innerHTML += `
            <div class="item-aluno-linha">
                <div class="aluno-info-linha">
                    <img src="${fotoUrl}" class="avatar-aluno">
                    <span>${aluno.nome} ${badge}</span>
                </div>
                <div class="combo-botoes">
                    ${botaoCargo}
                    <button class="btn-linha-crud" onclick="abrirModalAluno('${aluno.nome}')">Editar</button>
                    <button class="btn-linha-crud excluir" onclick="deletarEstudanteMatriculado('${aluno.nome}')">Excluir</button>
                </div>
            </div>
        `;
    });
}

function atribuirCargo(nomeAluno, tipoCargo) {
    let emailInput = prompt(`Para dar este cargo a ${nomeAluno}, digite o email institucional:\n(Obrigatório terminar em @aluno.ce.gov.br)`);
    if (!emailInput) return;

    let emailFormatado = emailInput.trim().toLowerCase();

    if (!emailFormatado.endsWith('@aluno.ce.gov.br')) {
        return dispararToast('danger', 'Erro: O e-mail deve ser @aluno.ce.gov.br');
    }

    let aluno = bdTurmas[sessaoAtiva.turmaEdicao].find(a => a.nome === nomeAluno);
    if (aluno) {
        aluno.email = emailFormatado;
        aluno.cargo = tipoCargo;

        let nomeCargo = tipoCargo === 'lider' ? 'Líder' : (tipoCargo === 'vice' ? 'Vice-Líder' : 'Secretário(a)');

        salvarDadosLocais();
        sincronizarInterface();
        dispararToast('success', `${nomeAluno} agora é ${nomeCargo}!`);
    }
}

function removerCargo(nomeAluno) {
    if (confirm(`Tirar o cargo de ${nomeAluno}? O aluno perderá acesso ao sistema.`)) {
        let aluno = bdTurmas[sessaoAtiva.turmaEdicao].find(a => a.nome === nomeAluno);
        if (aluno) {
            delete aluno.email;
            delete aluno.cargo;
            salvarDadosLocais();
            sincronizarInterface();
            dispararToast('info', `Cargo removido com sucesso.`);
        }
    }
}

function abrirModalAluno(nomeEstudante = '') {
    if (!sessaoAtiva.turmaEdicao) return dispararToast('warning', 'Crie uma turma primeiro.');

    document.getElementById('modal-aluno').classList.add('ativo');
    const inputAntigo = document.getElementById('modal-aluno-nome-antigo');
    const inputNome = document.getElementById('modal-aluno-nome');
    const inputFoto = document.getElementById('modal-aluno-foto');
    const selectTurma = document.getElementById('modal-aluno-turma');

    if (nomeEstudante) {
        document.getElementById('modal-titulo').innerText = "Editar Estudante";
        const alunoObj = bdTurmas[sessaoAtiva.turmaEdicao].find(a => a.nome === nomeEstudante);
        inputAntigo.value = nomeEstudante;
        inputNome.value = alunoObj.nome;
        inputFoto.value = alunoObj.foto;
        selectTurma.value = sessaoAtiva.turmaEdicao;
    } else {
        document.getElementById('modal-titulo').innerText = "Adicionar Novo Aluno";
        inputAntigo.value = "";
        inputNome.value = "";
        inputFoto.value = "";
        selectTurma.value = sessaoAtiva.turmaEdicao;
    }
}

function fecharModalAluno() { document.getElementById('modal-aluno').classList.remove('ativo'); }

function salvarDadosModalAluno() {
    const nomeAntigo = document.getElementById('modal-aluno-nome-antigo').value;
    const nomeNovo = document.getElementById('modal-aluno-nome').value.trim();
    const fotoNova = document.getElementById('modal-aluno-foto').value.trim();
    const turmaDestino = document.getElementById('modal-aluno-turma').value;

    if (!nomeNovo) return dispararToast('warning', 'Nome obrigatório.');

    if (nomeAntigo === "") {
        bdTurmas[turmaDestino].push({ nome: nomeNovo, foto: fotoNova });
        dispararToast('success', 'Aluno cadastrado!');
    }
    else {
        let indexVelho = bdTurmas[sessaoAtiva.turmaEdicao].findIndex(a => a.nome === nomeAntigo);
        bdTurmas[sessaoAtiva.turmaEdicao].splice(indexVelho, 1);
        bdTurmas[turmaDestino].push({ nome: nomeNovo, foto: fotoNova });

        if (nomeAntigo !== nomeNovo && pautaFrequencia[nomeAntigo]) {
            pautaFrequencia[nomeNovo] = pautaFrequencia[nomeAntigo];
            delete pautaFrequencia[nomeAntigo];
        }

        if (sessaoAtiva.turmaEdicao !== turmaDestino) dispararToast('info', 'Aluno movido de turma.');
        else dispararToast('success', 'Dados atualizados.');
    }

    salvarDadosLocais();
    inicializarPautaPadrao();
    fecharModalAluno();
    sincronizarInterface();
}

function deletarEstudanteMatriculado(nome) {
    if (confirm(`Excluir o aluno ${nome}?`)) {
        bdTurmas[sessaoAtiva.turmaEdicao] = bdTurmas[sessaoAtiva.turmaEdicao].filter(a => a.nome !== nome);
        delete pautaFrequencia[nome];

        salvarDadosLocais();
        sincronizarInterface();
        dispararToast('danger', 'Estudante removido.');
    }
}

// ==========================================
// 7. ADIÇÃO EM MASSA
// ==========================================
function abrirModalMassa() {
    if (!sessaoAtiva.turmaEdicao) return dispararToast('warning', 'Crie uma turma primeiro.');
    document.getElementById('texto-alunos-massa').value = "";
    document.getElementById('modal-massa').classList.add('ativo');
}

function fecharModalMassa() { document.getElementById('modal-massa').classList.remove('ativo'); }

function salvarAlunosMassa() {
    const texto = document.getElementById('texto-alunos-massa').value;
    const linhas = texto.split('\n').map(l => l.trim()).filter(l => l.length > 0);

    if (linhas.length === 0) return dispararToast('warning', 'A lista está vazia.');

    linhas.forEach(nomeAluno => {
        const jaExiste = bdTurmas[sessaoAtiva.turmaEdicao].some(a => a.nome.toLowerCase() === nomeAluno.toLowerCase());
        if (!jaExiste) bdTurmas[sessaoAtiva.turmaEdicao].push({ nome: nomeAluno, foto: "" });
    });

    salvarDadosLocais();
    inicializarPautaPadrao();
    fecharModalMassa();
    sincronizarInterface();
    dispararToast('success', `${linhas.length} alunos processados na turma.`);
}

function enviarPautaParaPHP() {
    const botao = document.querySelector('.btn-enviar-email');
    botao.innerText = "Salvando e Enviando...";
    botao.disabled = true;

    setTimeout(() => {
        const dataPauta = document.getElementById('data-hoje').value;
        const idUnico = new Date().getTime();
        const dataHoraEnvio = new Date().toLocaleString('pt-BR');

        const registroEnvio = {
            id: idUnico,
            dataPauta: dataPauta,
            turma: sessaoAtiva.turmaDiario,
            responsavel: document.getElementById('nome-usuario-logado').innerText,
            dataHoraEnvio: dataHoraEnvio,
            pautaCopia: JSON.parse(JSON.stringify(pautaFrequencia))
        };

        bdHistorico.unshift(registroEnvio);
        salvarDadosLocais();

        dispararToast('success', `Chamada de ${sessaoAtiva.turmaDiario} arquivada e enviada!`);
        botao.innerText = "📧 Enviar Frequência";
        botao.disabled = false;

        if (document.getElementById('aba-secretaria').classList.contains('ativo')) {
            renderizarHistoricoSecretaria();
        }
    }, 800);
}

function dispararToast(tipo, mensagem) {
    const container = document.getElementById('toast-container');
    if (!container) return;
    const box = document.createElement('div');
    box.className = `toast-box ${tipo}`;
    box.innerText = mensagem;
    container.appendChild(box);
    setTimeout(() => { box.style.opacity = '0'; setTimeout(() => box.remove(), 300); }, 4000);
}

// ==========================================
// 8. MÓDULO DA SECRETARIA (Acompanhamento e Impressão)
// ==========================================
function atualizarFiltroTurmaSecretaria() {
    const turmas = Object.keys(bdTurmas);
    let opcoes = `<select class="input-form" id="filtro-turma-sec" onchange="renderizarHistoricoSecretaria()">
                    <option value="todas">Todas as Turmas</option>`;
    turmas.forEach(t => opcoes += `<option value="${t}">${t}</option>`);
    opcoes += `</select>`;
    const wrapper = document.getElementById('wrapper-filtro-turma-sec');
    if (wrapper) wrapper.innerHTML = opcoes;
}

function limparFiltrosSecretaria() {
    document.getElementById('filtro-turma-sec').value = "todas";
    document.getElementById('filtro-data-sec').value = "";
    document.getElementById('filtro-status-sec').value = "todos";
    renderizarHistoricoSecretaria();
}

function excluirRelatorio(idRegistro) {
    if (confirm("Tem certeza que deseja apagar este relatório definitivamente?")) {
        bdHistorico = bdHistorico.filter(reg => reg.id !== idRegistro);
        salvarDadosLocais();
        renderizarHistoricoSecretaria();
        dispararToast('info', 'Relatório excluído do sistema.');
    }
}

function imprimirRelatorioTexto(idRegistro) {
    const reg = bdHistorico.find(h => h.id === idRegistro);
    if (!reg) return dispararToast('danger', 'Registro não encontrado.');

    const alunos = bdTurmas[reg.turma] || [];
    let textoImpressao = ``;

    textoImpressao += `======================================================\n`;
    textoImpressao += `  RELATORIO OFICIAL DE FREQUENCIA - SGE SECRETARIA\n`;
    textoImpressao += `======================================================\n\n`;
    textoImpressao += `TURMA/CURSO    : ${reg.turma}\n`;
    textoImpressao += `DATA DA PAUTA  : ${reg.dataPauta.split('-').reverse().join('/')}\n`;
    textoImpressao += `RESPONSAVEL    : ${reg.responsavel}\n`;
    textoImpressao += `HORA DO REGISTRO: ${reg.dataHoraEnvio}\n`;
    textoImpressao += `AUTENTICACAO   : SGE-HASH-${reg.id}\n\n`;
    textoImpressao += `------------------------------------------------------\n`;
    textoImpressao += ` NOME DO ESTUDANTE              MAPA DE AULAS (1-9)   \n`;
    textoImpressao += `------------------------------------------------------\n`;

    let qtdPresentes = 0;
    let qtdFaltas = 0;

    const alunosSort = [...alunos].sort((a, b) => a.nome.localeCompare(b.nome));

    alunosSort.forEach(aluno => {
        let statusSigla = reg.pautaCopia[aluno.nome] || 'P';
        let arrStatus = Array.isArray(statusSigla) ? statusSigla : Array(9).fill(statusSigla);

        let visualAulas = arrStatus.join(' ');
        let faltasNoDia = arrStatus.filter(s => s === 'F').length;
        let justNoDia = arrStatus.filter(s => s === 'J').length;

        let resumoText = "PRESENTE";
        if (faltasNoDia === 9) resumoText = "FALTA INTEGRAL";
        else if (justNoDia === 9) resumoText = "JUSTIFICADO INTEGRAL";
        else if (faltasNoDia > 0 || justNoDia > 0) resumoText = `${faltasNoDia} Faltas / ${justNoDia} Just.`;

        if (faltasNoDia > 0) qtdFaltas++; else qtdPresentes++;

        let linhaNome = aluno.nome.padEnd(30, '.');
        textoImpressao += `${linhaNome} [ ${visualAulas} ] ( ${resumoText} )\n`;
    });

    textoImpressao += `\n------------------------------------------------------\n`;
    textoImpressao += `TOTAL DE ALUNOS NA TURMA: ${alunos.length}\n`;
    textoImpressao += `TOTAL DE 100% PRESENTES : ${qtdPresentes}\n`;
    textoImpressao += `TOTAL COM AUSENCIAS     : ${qtdFaltas}\n`;
    textoImpressao += `======================================================\n`;
    textoImpressao += `\n\n\n\n_________________________________________________\n`;
    textoImpressao += `        Assinatura do Responsavel / Secretaria\n`;

    const janelaImpressao = window.open('', '_blank', 'width=800,height=600');
    janelaImpressao.document.write(`
        <html>
            <head><title>Relatório de Frequência - ${reg.turma}</title></head>
            <body style="padding: 20px;">
                <pre style="font-family: 'Courier New', Courier, monospace; font-size: 14px; color: #000;">${textoImpressao}</pre>
                <script>window.print();</script>
            </body>
        </html>
    `);
    janelaImpressao.document.close();
}

function promoverLider(nomeAluno) {
    let emailInput = prompt(`Para tornar ${nomeAluno} líder, digite o email institucional dele:\n(Obrigatório terminar em @aluno.ce.gov.br)`);
    if (!emailInput) return;

    let emailFormatado = emailInput.trim().toLowerCase();

    if (!emailFormatado.endsWith('@aluno.ce.gov.br')) {
        return dispararToast('danger', 'Erro: O e-mail deve ser @aluno.ce.gov.br');
    }

    let aluno = bdTurmas[sessaoAtiva.turmaEdicao].find(a => a.nome === nomeAluno);
    if (aluno) {
        aluno.email = emailFormatado;
        salvarDadosLocais();
        sincronizarInterface();
        dispararToast('success', `${nomeAluno} agora é líder da turma!`);
    }
}

// CORREÇÃO: Removido o conflito e a chave '}' órfã no fim do script
function removerLider(nomeAluno) {
    if (confirm(`Tirar o cargo de líder de ${nomeAluno}? Ele perderá o acesso ao sistema.`)) {
        let aluno = bdTurmas[sessaoAtiva.turmaEdicao].find(a => a.nome === nomeAluno);
        if (aluno) {
            delete aluno.email;
            salvarDadosLocais();
            sincronizarInterface();
            dispararToast('info', `Cargo de líder removido.`);
        }
    }
}

function renderizarHistoricoSecretaria() {
    const filtroTurma = document.getElementById('filtro-turma-sec').value;
    const filtroData = document.getElementById('filtro-data-sec').value;
    const tbody = document.getElementById('tabela-historico-secretaria');

    if (!tbody) return;
    tbody.innerHTML = "";

    let dadosFiltrados = bdHistorico.filter(reg => {
        let passaTurma = (filtroTurma === "todas" || reg.turma === filtroTurma);
        let passaData = (filtroData === "" || reg.dataPauta === filtroData);
        return passaTurma && passaData;
    });

    if (dadosFiltrados.length === 0) {
        tbody.innerHTML = `<tr><td colspan="3" style="text-align:center; padding: 30px; color: var(--texto-s);">Nenhum envio registrado com estes filtros.</td></tr>`;
        return;
    }

    dadosFiltrados.forEach(reg => {
        let dataPtBr = reg.dataPauta.split('-').reverse().join('/');

        tbody.innerHTML += `
            <tr class="linha-clicavel" style="cursor:pointer;" onclick="abrirModalRelatorio(${reg.id})">
                <td><strong>${dataPtBr}</strong></td>
                <td>${reg.turma}</td>
                <td>
                    <div style="font-size: 13px;">${reg.responsavel}</div>
                    <div style="font-size: 11px; color: var(--texto-s);">Enviado em: ${reg.dataHoraEnvio}</div>
                </td>
            </tr>
        `;
    });
}

function abrirModalRelatorio(idRegistro) {
    const relatorio = bdHistorico.find(r => r.id === idRegistro);
    if (!relatorio) return;

    let qtdPresentes = 0;
    let qtdFaltas = 0;
    let listaFaltosos = [];

    for (let nomeAluno in relatorio.pautaCopia) {
        let statusSigla = relatorio.pautaCopia[nomeAluno];
        let arrStatus = Array.isArray(statusSigla) ? statusSigla : Array(9).fill(statusSigla);

        let faltasNoDia = arrStatus.filter(s => s === 'F').length;
        let justNoDia = arrStatus.filter(s => s === 'J').length;

        if (faltasNoDia > 0 || justNoDia > 0) {
            qtdFaltas++;
            listaFaltosos.push(`${nomeAluno.split(' ')[0]} [${arrStatus.join('')}]`);
        } else {
            qtdPresentes++;
        }
    }

    let textoFaltosos = listaFaltosos.length > 0 ? listaFaltosos.join(', ') : 'Todos os alunos compareceram a todas as aulas.';
    let dataPtBr = relatorio.dataPauta.split('-').reverse().join('/');

    const divConteudo = document.getElementById('conteudo-relatorio');

    divConteudo.innerHTML = `
        <div class="detalhe-relatorio"><strong>Data da Pauta:</strong> <span>${dataPtBr}</span></div>
        <div class="detalhe-relatorio"><strong>Turma:</strong> <span>${relatorio.turma}</span></div>
        <div class="detalhe-relatorio"><strong>Enviado por:</strong> <span>${relatorio.responsavel}</span></div>
        <div class="detalhe-relatorio"><strong>Horário:</strong> <span>${relatorio.dataHoraEnvio}</span></div>
        
        <div class="detalhe-relatorio" style="margin-top: 10px; background: #F8FAFC; padding: 10px; border-radius: 6px;">
            <strong>✅ 100% Presentes:</strong> <span style="color: #16A34A; font-weight: bold; font-size: 16px;">${qtdPresentes}</span>
        </div>
        <div class="detalhe-relatorio" style="background: #F8FAFC; padding: 10px; border-radius: 6px;">
            <strong>❌ Alunos com Ausência/Saída:</strong> <span style="color: #DC2626; font-weight: bold; font-size: 16px;">${qtdFaltas}</span>
        </div>
        
        <div class="resumo-faltas">
            <strong>Lista de Ocorrências [Grade de Aulas]:</strong><br>
            <div style="margin-top: 6px; font-family: monospace; font-size: 12px; line-height: 1.6;">${textoFaltosos}</div>
        </div>

        <div style="display: flex; gap: 10px; margin-top: 20px;">
            <button class="btn-enviar-email" style="flex: 1;" onclick="imprimirRelatorioTexto(${relatorio.id})">🖨️ Imprimir</button>
            <button class="btn-linha-crud excluir" style="flex: 1;" onclick="excluirRelatorioPeloModal(${relatorio.id})">🗑️ Excluir</button>
        </div>
    `;

    document.getElementById('modal-relatorio').classList.add('ativo');
}

function fecharModalRelatorio() {
    document.getElementById('modal-relatorio').classList.remove('ativo');
}

function excluirRelatorioPeloModal(idRegistro) {
    if (confirm("Tem certeza que deseja apagar este relatório definitivamente?")) {
        bdHistorico = bdHistorico.filter(reg => reg.id !== idRegistro);
        salvarDadosLocais();
        renderizarHistoricoSecretaria();
        fecharModalRelatorio();
        dispararToast('info', 'Relatório excluído do sistema.');
    }
}

function mudarAulaAtiva(index) {
    aulaAtiva = parseInt(index);
    sincronizarInterface();
}

function marcarDiaTodo(nomeEstudante, status) {
    pautaFrequencia[nomeEstudante] = Array(9).fill(status);
    salvarDadosLocais();
    sincronizarInterface();
}

function replicarFrequenciaAulaAtiva() {
    if (confirm(`Deseja copiar as presenças e faltas da ${aulaAtiva + 1}ª Aula para todas as outras aulas do dia de toda a turma?`)) {
        for (let nome in pautaFrequencia) {
            if (Array.isArray(pautaFrequencia[nome])) {
                let statusAtual = pautaFrequencia[nome][aulaAtiva];
                pautaFrequencia[nome] = Array(9).fill(statusAtual);
            }
        }
        salvarDadosLocais();
        sincronizarInterface();
        dispararToast('success', `Frequência da ${aulaAtiva + 1}ª Aula replicada para o dia completo!`);
    }
}