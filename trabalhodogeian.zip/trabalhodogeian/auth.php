<?php
// Define que este arquivo responde em formato JSON (linguagem que o JavaScript entende)
header('Content-Type: application/json');

// Só processa se o envio for via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Pega os dados enviados pelo JavaScript Fetch
    $dadosRecebidos = json_decode(file_get_contents("php://input"), true);
    
    $email = trim(strtolower($dadosRecebidos['email'] ?? ''));
    $senha = $dadosRecebidos['senha'] ?? '';

    // Validação institucional (Regra da sua escola)
    $isAluno = str_ends_with($email, '@aluno.ce.gov.br');
    $isProf = str_ends_with($email, '@prof.ce.gov.br');

    if (!$isAluno && !$isProf) {
        // Retorna erro para o JavaScript
        echo json_encode([
            "sucesso" => false, 
            "mensagem" => "Acesso negado! Use @aluno.ce.gov.br ou @prof.ce.gov.br"
        ]);
        exit;
    }

    // Se tudo der certo, o PHP valida e manda a resposta positiva
    echo json_encode([
        "sucesso" => true,
        "email" => $email,
        "isProf" => $isProf
    ]);
    exit;
}
?>